import React from "react";

const Test = () => {
    return <div>Test Component</div>;
};

export default Test;
